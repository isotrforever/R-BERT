## 其他参考评测数据

+ wordsim-240，10分制
+ wordsim-297, 5分制

其中可能会有一些表外词汇导致无法计算。</p>
参考项目：[Word_Similarity_and_Word_Analogy](https://github.com/bamtercelboo/Word_Similarity_and_Word_Analogy)
