# -*- encoding: utf-8 -*-
import numpy as np
from Hybrid_Sim import HybridSim


def word_sim(words):
    import synonyms

    words = list(set(words))

    # word2uid, uid2word
    word2uid = {}
    uid2word = {}
    for index, word in enumerate(words):
        word2uid[word] = index
        uid2word[index] = word

    vec_sim_mat = np.zeros((len(words), len(words)))
    cil_sim_mat = np.zeros((len(words), len(words)))

    for word_0 in words:
        for word_1 in words:
            vec_sim_mat[word2uid[word_0], word2uid[word_1]] = synonyms.compare(word_0, word_1)
            cil_sim_mat[word2uid[word_0], word2uid[word_1]] = HybridSim.get_Final_sim(word_0, word_1)

    return word2uid, uid2word, vec_sim_mat, cil_sim_mat


if __name__ == '__main__':
    print(HybridSim.get_Final_sim("打磨", "混凝土"))
