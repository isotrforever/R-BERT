import numpy as np


def load_re_map(file_name):
    with open(file_name, "r") as rf:
        lines = rf.readlines()

    words = lines[0].split(",")[1:]
    re_map = {}
    # dense_mat = np.zeros((len(words), len(words)))
    for row, line in enumerate(lines[1:]):
        for col, number in enumerate(line.split(",")[1:]):
            number = float(number)
            if number > 0:
                re_map[(words[row], words[col])] = 1

    return re_map


def relation_co(words_0, words_1, re_map):
    words_0 = list(set(words_0))
    words_1 = list(set(words_1))

    count = 0
    for w_0 in words_0:
        for w_1 in words_1:
           if (w_0, w_1) in re_map or (w_1, w_0) in re_map:
               count += 1

    return np.true_divide(count*count, len(words_0)*len(words_1))


def main():
    re_map = load_re_map(file_name="relation_map.csv")

    with open("concept.txt", "r") as rf:
        lines = [line.strip().split(",") for line in rf.readlines()]

    co_map = {}
    for i in range(len(lines)):
        for j in range(i, len(lines)):
            co_map[(i, j)] = relation_co(lines[i], lines[j], re_map)

    return co_map


if __name__ == '__main__':
    pass
